import java.util.Scanner;

public class StringPalindromeChecker {

	public static boolean checkPalindrome(String str)
	{
		  String reverseStr = "";
		  
	        // Initializing a new boolean variable for the
	        // answer
	        boolean ans = false;
	 
	        for (int i = str.length() - 1; i >= 0; i--) {
	        	reverseStr = reverseStr + str.charAt(i);
	        }
	 
	        // Checking if both the strings are equal
	        if (str.equals(reverseStr)) {
	            ans = true;
	        }
	        return ans;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  // Input string
		Scanner scan1 = new Scanner(System.in);
        String str = "check string palindrome";
        System.out.println("Enter a String ..");
        str = scan1.nextLine();
        System.out.println(str);
        // Convert the string to lowercase
        str = str.toLowerCase();
        boolean A = checkPalindrome(str);
        System.out.println(A);

	}

}
