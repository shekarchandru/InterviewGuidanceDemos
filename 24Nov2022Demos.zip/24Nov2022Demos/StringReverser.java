import java.util.Scanner;

public class StringReverser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		Scanner scan1 = new Scanner(System.in);
		
		System.out.println("Enter a String");
		str = scan1.nextLine();
		String reversedString;
		String reverseStr = "";
		  
        
            for (int i = str.length() - 1; i >= 0; i--) {
        	reverseStr = reverseStr + str.charAt(i);
            }
            System.out.println("The Reveresed String is "+reverseStr);
	}

}
