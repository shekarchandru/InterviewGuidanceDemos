import java.util.Scanner;

public class WordReverser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str;
		Scanner scan1 = new Scanner(System.in);
		
		System.out.println("Enter a String");
		str = scan1.nextLine();
		String[] stringArrays = new String[100];
		stringArrays = str.split(" ");
		System.out.println("Words in Reverse Order");
		for(int i=stringArrays.length-1;i>=0;i--)
		{
			System.out.print(stringArrays[i]+" ");
		}
		

	}

}
