import java.util.Scanner;

public class SwapWith2Variables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int x = 100;
		 int y = 500;
		 Scanner scan1 = new Scanner(System.in);
		 System.out.println("Enter First Number ");
		 x = scan1.nextInt();
		 System.out.println("Enter Second Number ");
		 y = scan1.nextInt();
	        System.out.println("Before Swapping X :"+x+" And Y "+y);
	        x = x + y; // 600
	        y = x - y;  //100
	        x = x - y;//500
	        System.out.println("After Swapping X :"+x+" And Y "+y);

	}

}
