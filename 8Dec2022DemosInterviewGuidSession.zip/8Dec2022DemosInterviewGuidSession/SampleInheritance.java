class BaseClass
{
	int score = 75;
	public void display()
	{
		System.out.println("Displaying Child Class method "+score);
	}
	
}
class Derived extends BaseClass
{
	int score = 85;
	public void display()
	{
		System.out.println("Displaying Derived Class Method "+score);
	}
	
	
}
public class SampleInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BaseClass bc = new BaseClass();
		bc.display();
		System.out.println(bc.score);
		bc = new Derived();
		bc.display();
		System.out.println(bc.score);
		

	}

}
