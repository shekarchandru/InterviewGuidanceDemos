package com.gl.inter.dec08;

public class StaticExample {

	/*
	 * int score;
	 * static int graceMarks=5;
	 */
	int nonStaticVar;
	static int staticVar;
	/*
	 * Non Static Methods can access static as well as non static variables; 
	 * Static Methods can access only static variables
	 */
	public void nonStaticMethod1()
	{
		staticMethod1();
		nonStaticVar++;
		staticVar++;
		System.out.println("The NONSTATIC variable accessed in nonStaticMethod 1 :"+nonStaticVar);
		System.out.println("STATIC variable accessed in nonStaticMethod 1  :"+staticVar);
		
	}
	public static void staticMethod1()
	{
		//nonStaticVar++;
		
		staticVar++;
		System.out.println("STATIC variable accessed in StaticMethod 1  :"+staticVar);
	}
	public void nonStaticMethod2()
	{
		nonStaticVar++;
		staticVar++;
		System.out.println("The NONSTATIC variable accessed in nonStaticMethod 2 :"+nonStaticVar);
		System.out.println("STATIC variable accessed in nonStaticMethod 2  :"+staticVar);
		
	}
	public static void staticMethod2()
	{
		staticVar++;
		System.out.println("STATIC variable accessed in StaticMethod 2  :"+staticVar);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticExample stat1 = new StaticExample();
		StaticExample.staticMethod1();
		

		stat1.nonStaticMethod1();
		stat1.nonStaticMethod2();
	//	stat1.staticMethod1();
		
		StaticExample stat2 = new StaticExample();
		StaticExample.staticMethod2();
		stat2.nonStaticMethod1();
		stat2.nonStaticMethod2();
		staticVar++;
		System.out.println(staticVar);
		

	}

}
