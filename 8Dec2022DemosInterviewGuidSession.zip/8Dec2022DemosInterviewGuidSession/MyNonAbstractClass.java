package com.gl.inter.dec08;

abstract class MyClass2 {

/*	public abstract void abstractMethod1();
	public abstract void abstractMethod2();*/
	public abstract void abstractMethod3();
	
	public void nonAbstractMethod1()
	{
		System.out.println("Non AbstractMethod1 In Abstract Class");
	}
	public void nonAbstractMethod2()
	{
		System.out.println("Displaying NonAbstractMethod2");
	}
}
public class MyNonAbstractClass extends MyClass2{

	@Override
	public void nonAbstractMethod1()
	{
		System.out.println("Non AbstractMethod1 in Derived Class");
	}
	@Override
	public void abstractMethod3() {
		// TODO Auto-generated method stub
		System.out.println("Displaying abstractMethod3");
	}
	public static void main(String[] args)
	{
		//MyAbstractClass mac = new MyAbstractClass();
		MyNonAbstractClass mc = new MyNonAbstractClass();
		mc.nonAbstractMethod1();
		mc.nonAbstractMethod2();
		mc.abstractMethod3();
	}
	
}
