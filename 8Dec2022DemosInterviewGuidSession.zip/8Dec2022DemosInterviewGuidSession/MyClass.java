interface Banking
{
	int num1=10;
	static int num2=20;
	static final int num3=30;
	public void display();
	
}
class MyClass1 implements Banking
{
	public void display()
	{
		/*num1++;
		num2++;
		num3++;*/
		System.out.println(num1+" "+num2+" "+num3);
	}
}
public class MyClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass1 mc = new MyClass1();
		mc.display();
	}

}
