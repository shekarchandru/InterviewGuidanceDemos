import java.util.Scanner;

public class VowelFinder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str;
		char vowels[] = new char[500];
		Scanner scan1 = new Scanner(System.in);
		System.out.println("Enter a String");
		str = scan1.nextLine();
		for(int i=0;i<str.length();i++)
		{
			if((str.charAt(i) == 'A') || (str.charAt(i) == 'a')
					|| (str.charAt(i) == 'E') || (str.charAt(i) == 'e')
					|| (str.charAt(i) == 'I') || (str.charAt(i) == 'i')
					|| (str.charAt(i) == 'O') || (str.charAt(i) == 'o')
					|| (str.charAt(i) == 'U') || (str.charAt(i) == 'u'))
			{
				vowels[i] = str.charAt(i);
			}
		}
		
		
		int ctr=0;
	
		
		System.out.println("They are ");
		for(char c:vowels)
		{
			if((c == 'A') || (c == 'a')
					|| (c == 'E') || (c == 'e')
					|| (c == 'I') || (c == 'i')
					|| (c == 'O') || (c == 'o')
					|| (c == 'U') || (c == 'u'))
			{
				System.out.println(c);
				ctr++;
			}
		}
		System.out.println("The Vowel count is "+ctr);
		

	}

}
