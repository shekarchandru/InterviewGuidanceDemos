import java.util.Scanner;

public class NumberPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" Enter a number to check if it is Palindrome\n");
		Scanner Scn = new Scanner(System.in);
		int number = Scn.nextInt();   //423324  423324 //1234    4321

		int remainder, Sum = 0, temp;    

		temp = number;
		while (number > 0) {
			remainder = number % 10; // for getting reminder 1221 % 10 -->1
			Sum = (Sum * 10) + remainder; // sum = 0 * 10 ---> 0 + 1 -- 1
			number = number / 10;     ///    

		}
             if ( temp ==Sum)
            	 
            	 System.out.println( " Palindrome Number");
             
             else
            	 
            	 System.out.println( " Non Palindrome Number");

	}

}
